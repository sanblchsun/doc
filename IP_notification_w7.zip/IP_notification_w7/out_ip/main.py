import logging
import sys
import urllib.request
import socket
from loader import url_helper, external_ip_pattern, to_addrs, firma
from mail.send_mail import send_email_with_attachment
import ssl


def print_ip():
    ssl._create_default_https_context = ssl._create_unverified_context
    external_ip = urllib.request.urlopen(url_helper).read().decode('utf8')
    hostname = socket.gethostname()
    ip_local = socket.gethostbyname(hostname)
    str_my = "Имя устройства: {}. \n" \
             "Локальный IP адрес устройства: {}. \n" \
             "Сейчас внешний IP адрес для устройства: {}".format(hostname, ip_local, external_ip)
    if external_ip == external_ip_pattern:
        description = "{}, \n" \
                      "и это соответсвует, установленному ранее IP адресу.".format(str_my)
        # priority = ""
        logging.basicConfig(format=u'%(filename)s [LINE:%(lineno)d] #%(levelname)-8s [%(asctime)s]  %(message)s',
                            level=logging.INFO,
                            # level=logging.DEBUG,  # Можно заменить на другой уровень логгирования.
                            )
        logging.info("Сработал планировщик заданий\n"
                     "{}".format(description))
        sys.exit("Выход из программы, на почту уведомление не отправлялось.")
    else:
        description = "{}, " \
                      "ВНИМАНИЕ!!! это не соответсвует, установленному ранее IP адресу: {}. " \
                      "Примите меры".format(str_my,external_ip_pattern)
        priority = "Критично"
    send_email_with_attachment(firma=firma, e_mail=to_addrs, full_name="Я робот, слежу за внешним IP",
                               cont_telefon=" ", description=description, priority=priority)


if __name__ == '__main__':
    print_ip()
